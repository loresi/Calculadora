package calculadora;


import java.util.Scanner;


public class Calcu_tarea1 {
    

public static void main(String[] args) {
    
Scanner scanner = new Scanner (System.in);
Scanner reader = new Scanner(System.in);

 
int numero1 = 0;
int numero2 = 0;
int verif_num = 0;

     	
System.out.println("Introduce el primer número:");			
numero1 = reader.nextInt();
			
System.out.println("Introduce el segundo número:");
numero2 = reader.nextInt();


     int resultado_suma = numero1+numero2;
     int resultado_resta = numero1-numero2;
     int resultado_multi = numero1*numero2;
     int resultado_division = numero1/numero2;
     
     
System.out.println("La suma es " + ":" + numero1 + " + " + numero2 + " = " + resultado_suma);
System.out.println("La resta es " + ":" + numero1 + " - " + numero2 + " = " + resultado_resta);
System.out.println("La multiplicacion es " + ":" + numero1 + " * " + numero2 + " = " + resultado_multi);
System.out.println("La division es " + ":" + numero1 + " / " + numero2 + " = " + resultado_division);



//Se le pide al usuario que digite un nuevo numero y se verifica si es primo o no
System.out.print("");

System.out.println("Introduce un numero:");     
verif_num = reader.nextInt();


        int contador = 0;
        int i;
 
        for(i = 1; i <= verif_num; i++)
        {
            if((verif_num % i) == 0)
            {
                contador++;
            }
        }
 
        if(contador <= 2)
        {
            System.out.println("El numero es primo");
        }else{
            System.out.println("El numero no es primo");
           
        }
        
        
//Se le pide al usuario que digite un numero mayor o igual a 10 y se verifica si este es un polindromo 

int numero, aux, inverso = 0, cifra;

do {
     
     System.out.print("Ahora introduce un número mayor o igual a 10: ");
     numero = reader.nextInt();
     
} while (numero < 10);

//le damos la vuelta al número

        aux = numero;
        while (aux!=0){
            cifra = aux % 10;
            inverso = inverso * 10 + cifra;
            aux = aux / 10;
        }
        
        if(numero == inverso){
            System.out.println("El numero es un palindromo");
        }else{
            System.out.println("El numero no es un palindromo");
        }

    
    

}
}
        